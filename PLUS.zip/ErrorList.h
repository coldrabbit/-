#pragma once
#include"problem.h"
#include"grade.h"
#include<string>
#include<io.h>
#include<fstream>
#include"user.h"
#include<iostream>

using namespace std;

class ErrorList
{
public:
    int index;
	string* list;//�ļ�
	int list_num;//�ļ�����
	grade* Grade;//�꼶
public:
	ErrorList(grade* G) {
		Grade = G;
        index = -1;
		list = new string[100];
	}
	void set() {
		list_num = 0;
		intptr_t hFile = 0;
		struct _finddata_t fileinfo;
		//��ȡ�ļ������ļ�
        if ((hFile = _findfirst((to_string(Grade->Grade) + "\\*").c_str(), &fileinfo)) != -1) {
			do {
				if (!(fileinfo.attrib & _A_SUBDIR) && fileinfo.name != "." && fileinfo.name != "..") {
					list[list_num] = fileinfo.name;
                    list[list_num] = list[list_num].substr(0, list[list_num].rfind("."));
					list_num++;
				}
			} while (_findnext(hFile, &fileinfo) == 0);
		}
	}
	~ErrorList() {
		delete[] list;
	}
    void getprob(int Index, user* User) {
        index = Index;
		fstream file;
        int num,error_num;
        file.open(to_string(Grade->Grade) + "\\" + this->list[index] + ".txt", ios_base::in);
        file >> num >> error_num >> User->rrn >> User->type;
        User->num = num;
        User->error_num = error_num;
        for (int i = 0; i < User->num; i++) {
            file >> User->prob[i].prob >> User->prob[i].ans >> User->prob[i].stu_ans;
            if (User->type == 5) {
                file >> User->prob[i].rest >> User->prob[i].stu_rest;
			}
        }
        User->checkans();
        User->savename = list[index];
	}
};

