#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtCharts>
using namespace QtCharts;
#include "user.h"
#include "ErrorList.h"
#include "grade.h"


class QStackedwidget;

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    void switchPage();
    void flush();
    void trans();
    void settings();
    void getrrn();
    void disable_item();
    void timerUpDate();
    void settime();
private:
    Ui::MainWindow *ui;
    int page_all;
    int page;
    int status;
    float RRN[10];
    grade* Grade=new grade();
    user *User = new user(Grade);
    ErrorList *Errorlist = new ErrorList(Grade);
    QLineSeries *lineseries = new QLineSeries();
    QChart *chart = new QChart();
    QTimer *timer = new QTimer();
    int time;
};

#endif // MAINWINDOW_H
