#pragma once
#include<fstream>

using namespace std;

class grade
{
public:
	int Grade;
public:
	grade() {
		fstream fin;
		fin.open("Grade.txt", ios_base::binary | ios_base::in);
		fin >> Grade;
		fin.close();
	}
	~grade() {

	}
	void change(int newgrade) {
		Grade = newgrade;
		fstream fout;
		fout.open("Grade.txt", ios_base::binary | ios_base::out);
		fout << Grade;
	}
};

