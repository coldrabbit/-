#pragma once
#include"grade.h"
#include"problem.h"
#include<string>
#include<ctime>
#include<random>
#include<vector>
#include<iostream>
#include<fstream>
#include<vector>
#include<cstdio>
#pragma warning(disable : 4996)

using namespace std;

class user
{
public:
	problem* prob;		//��Ŀ
	problem* errprob;	//������Ŀ
	grade* Grade;		//�꼶
	string fname;		//��Ŀ�ļ�����
    string savename;
	bool error;			//�����ǣ�1Ϊ��ȡ����
    int num, type, error_num, nfn;		//��Ŀ��������Ŀ���ͼӷ���1��������2���Ӽ���ϣ�3���˷���4�� ������5�� �����ϣ�6
    float rrn;
public:
	user(grade* G) {
		Grade = G;
        prob = new problem[40]();
        errprob = new problem[40]();
	}
	void set(int num_, int type_) {
		num = num_;
		type = type_;
		error = 0;
        nfn = 0;
		error_num = 0;
		this->getfname();
		this->get();
	}
	~user() {
		delete[] prob;
		delete[] errprob;
	}
	void checkans() {//����
		int i,j;
		for (i = 0, j = 0; i < num; i++) {
			prob[i].check();
            if(prob[i].stu_ans == -1){
                nfn++;
            }
            else if (!prob[i].correct) {
				errprob[j] = prob[i];
				error_num++;
				j++;
			}
		}
        rrn = (float(num - error_num - nfn))/num;
        fstream file;
        file.open("RRN.txt", ios_base::in | ios_base::out);
        vector<float> RRN;
        float r;
        for(int i = 0; i<10 ; i++){
            file >> r;
            RRN.push_back(r);
        }
        file.seekp(0,ios::beg);
        RRN.insert(RRN.begin(), rrn);
        for(unsigned int i = 0; i<10;i++){
            if(RRN[i]<=1&&RRN[i]>=0)
                file << RRN[i] << endl;
            else
                file << 0 << endl;
        }
        file.close();
	}
    void save_error(int status) {//�������,�ļ�����������ʱ��,  ������\n ��Ŀ����\n��Ŀ
        fstream file;
        if(status == 1){

            const time_t t = time(NULL);
            const struct tm* Time = localtime(&t);
            string filename;
            char ch[50];
            strftime(ch, sizeof(ch) - 1, "%Y-%m-%d %H.%M", localtime(&t));
            filename = to_string(Grade->Grade) + "\\" + ch + ".txt";
            savename = filename;
        }
        if(rrn == 1){
            remove(savename.c_str());
        }
        else{
            file.open( savename, ios_base::out);
            file << num << " " << error_num << " " << rrn << " " << type << endl;
            for (int i = 0; i < num && prob[i].ans != -1; i++) {
                file << prob[i].prob << " " << prob[i].ans << " " << prob[i].stu_ans;
                if (type == 5) {
                    file << " " << prob[i].rest << " " << prob[i].stu_rest;
                }
                file << endl;
            }
            file.close();
        }
	}
private:
	void get() {//���ļ��л�ȡ��Ŀ
		fstream fin;
		int locate;
		vector<problem> p;
		problem q;
		srand(time(NULL));
		fin.open(fname, ios_base::binary | ios_base::in | ios_base::out);
		int i;
		//��ȡ������Ŀ
        for (i = 0; fin >> q.prob >> q.ans; i++) {
			if (type == 5) {
				fin >> q.rest;
			}
			p.push_back(q);
		}
		fin.close();
		//ѡ��
		if (i >= num) {
			for (int j = 0; j < num;) {
				int index = rand() % (i + 1);
				prob[j] = p[index];
				p.erase(p.begin() + index);
				j++;
				i--;
			}
			fstream file;
			file.open(fname, ios_base::binary | ios_base::out);
			for (int j = 0; j < i; j++) {
				file << p[j].prob << " " << p[j].ans;
				if (type == 5) {
					file << " " << p[j].rest;
				}
				file << endl;
			}
		}
		else error = 1;
	}
	void getfname() {//��ȡ�ļ�����
		fname = to_string(Grade->Grade) + "�꼶";
		if (type == 1) fname += "�ӷ�";
		else if (type == 2) fname += "����";
		else if (type == 3) fname += "�Ӽ����";
		else if (type == 4) fname += "�˷�";
		else if (type == 5) fname += "����";
		else if (type == 6) fname += "��������";
		this->fname += ".txt";
	}
	
};

