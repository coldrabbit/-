#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->subButton->setStyleSheet("QPushButton{border-image: url(:/submit.png);}");
    ui->subButton->setToolTip("提交");
    status = 0;
    time = 0;
    disable_item();
    connect(ui->aButton,&QPushButton::clicked,this,&MainWindow::switchPage);
    connect(ui->bButton,&QPushButton::clicked,this,&MainWindow::switchPage);
    connect(ui->cButton,&QPushButton::clicked,this,&MainWindow::switchPage);
    connect(ui->dButton,&QPushButton::clicked,this,&MainWindow::switchPage);
    connect(ui->sButton,&QPushButton::clicked,this,&MainWindow::switchPage);
    connect(ui->pushButton_ret,&QPushButton::clicked,this,&MainWindow::switchPage);
    connect(ui->pushButton_all,&QPushButton::clicked,this,&MainWindow::switchPage);
    connect(ui->pushButton_one,&QPushButton::clicked,this,&MainWindow::switchPage);
    connect(ui->subButton,&QPushButton::clicked,this,&MainWindow::switchPage);
    connect(ui->pushButton_0,&QPushButton::clicked,this,&MainWindow::switchPage);
    connect(ui->pushButton_1,&QPushButton::clicked,this,&MainWindow::switchPage);
    connect(ui->pushButton_2,&QPushButton::clicked,this,&MainWindow::switchPage);
    connect(ui->pushButton_3,&QPushButton::clicked,this,&MainWindow::switchPage);
    connect(ui->pushButton_4,&QPushButton::clicked,this,&MainWindow::switchPage);
    connect(ui->pushButton_5,&QPushButton::clicked,this,&MainWindow::switchPage);
    connect(ui->pushButton_6,&QPushButton::clicked,this,&MainWindow::switchPage);
    connect(ui->pushButton_7,&QPushButton::clicked,this,&MainWindow::switchPage);
    connect(ui->pushButton_8,&QPushButton::clicked,this,&MainWindow::switchPage);
    connect(ui->pushButton_9,&QPushButton::clicked,this,&MainWindow::switchPage);
    connect(ui->sButton,&QPushButton::clicked,this,&MainWindow::flush);
    connect(ui->lButton,&QPushButton::clicked,this,&MainWindow::flush);
    connect(ui->nButton,&QPushButton::clicked,this,&MainWindow::flush);
    connect(ui->pushButton_0,&QPushButton::clicked,this,&MainWindow::flush);
    connect(ui->pushButton_1,&QPushButton::clicked,this,&MainWindow::flush);
    connect(ui->pushButton_2,&QPushButton::clicked,this,&MainWindow::flush);
    connect(ui->pushButton_3,&QPushButton::clicked,this,&MainWindow::flush);
    connect(ui->pushButton_4,&QPushButton::clicked,this,&MainWindow::flush);
    connect(ui->pushButton_5,&QPushButton::clicked,this,&MainWindow::flush);
    connect(ui->pushButton_6,&QPushButton::clicked,this,&MainWindow::flush);
    connect(ui->pushButton_7,&QPushButton::clicked,this,&MainWindow::flush);
    connect(ui->pushButton_8,&QPushButton::clicked,this,&MainWindow::flush);
    connect(ui->pushButton_9,&QPushButton::clicked,this,&MainWindow::flush);
    connect(ui->pushButton_20,&QPushButton::clicked,this,&MainWindow::settings);
    connect(ui->lineEdit,&QLineEdit::editingFinished,this,&MainWindow::trans);
    connect(ui->lineEdit_1,&QLineEdit::editingFinished,this,&MainWindow::trans);
    connect(ui->lineEdit_2,&QLineEdit::editingFinished,this,&MainWindow::trans);
    connect(ui->lineEdit_3,&QLineEdit::editingFinished,this,&MainWindow::trans);
    connect(ui->lineEdit_4,&QLineEdit::editingFinished,this,&MainWindow::trans);
    connect(ui->lineEdit_5,&QLineEdit::editingFinished,this,&MainWindow::trans);
    connect(ui->lineEdit_6,&QLineEdit::editingFinished,this,&MainWindow::trans);
    connect(ui->lineEdit_7,&QLineEdit::editingFinished,this,&MainWindow::trans);
    connect(ui->lineEdit_8,&QLineEdit::editingFinished,this,&MainWindow::trans);
    connect(ui->lineEdit_9,&QLineEdit::editingFinished,this,&MainWindow::trans);
    connect(this->timer,&QTimer::timeout,this,&MainWindow::timerUpDate);
    timer->setInterval(1000);
    this->timer->start();
    connect(ui->sButton,&QPushButton::clicked,this,&MainWindow::settime);
}

MainWindow::~MainWindow()
{
    delete ui;
    delete User;
    delete Grade;
    delete Errorlist;
    delete lineseries;
    delete chart;
    delete timer;
}

void MainWindow::switchPage(){
    QPushButton *button = qobject_cast<QPushButton*>(sender());//得到按下的按钮的指针
    if(button == ui->aButton){
        if(ui->stackedWidget->currentIndex() == 1)
            return;
        else
            ui->stackedWidget->setCurrentIndex(status);
    }
    if(button == ui->bButton){
        if(ui->stackedWidget->currentIndex() == 3)
            return;
        else{
            ui->stackedWidget->setCurrentIndex(3);
            Errorlist->set();
            ui->label_10->setText(QString::fromStdString(Errorlist->list[0]));
            ui->label_10->setAlignment(Qt::AlignCenter);
            ui->label_11->setText(QString::fromStdString(Errorlist->list[1]));
            ui->label_11->setAlignment(Qt::AlignCenter);
            ui->label_12->setText(QString::fromStdString(Errorlist->list[2]));
            ui->label_12->setAlignment(Qt::AlignCenter);
            ui->label_13->setText(QString::fromStdString(Errorlist->list[3]));
            ui->label_13->setAlignment(Qt::AlignCenter);
            ui->label_14->setText(QString::fromStdString(Errorlist->list[4]));
            ui->label_14->setAlignment(Qt::AlignCenter);
            ui->label_15->setText(QString::fromStdString(Errorlist->list[5]));
            ui->label_15->setAlignment(Qt::AlignCenter);
            ui->label_16->setText(QString::fromStdString(Errorlist->list[6]));
            ui->label_16->setAlignment(Qt::AlignCenter);
            ui->label_17->setText(QString::fromStdString(Errorlist->list[7]));
            ui->label_17->setAlignment(Qt::AlignCenter);
            ui->label_18->setText(QString::fromStdString(Errorlist->list[8]));
            ui->label_18->setAlignment(Qt::AlignCenter);
            ui->label_19->setText(QString::fromStdString(Errorlist->list[9]));
            ui->label_19->setAlignment(Qt::AlignCenter);
        }
    }
    if(button == ui->cButton){
        if(ui->stackedWidget->currentIndex() == 4)
            return;
        else{
            lineseries->clear();
            ui->stackedWidget->setCurrentIndex(4);
            getrrn();
            lineseries->append(1, RRN[9]);
            lineseries->append(2, RRN[8]);
            lineseries->append(3, RRN[7]);
            lineseries->append(4, RRN[6]);
            lineseries->append(5, RRN[5]);
            lineseries->append(6, RRN[4]);
            lineseries->append(7, RRN[3]);
            lineseries->append(8, RRN[2]);
            lineseries->append(9, RRN[1]);
            lineseries->append(10, RRN[0]);
            chart->legend()->hide();  //隐藏图例
            chart->addSeries(lineseries);
            QValueAxis *axisX = new QValueAxis;//X轴
            axisX->setRange(1,10);
            axisX->setTitleText("最近十次表现");//标题
            axisX->setLabelFormat("%d");
            axisX->setTickCount(10);
            QValueAxis *axisY = new QValueAxis; //Y 轴
            axisY->setRange(0,1);
            axisY->setTitleText("正确率");
            axisY->setLabelFormat("%.2f"); //标签格式
            axisY->setTickCount(11);
            //为序列设置坐标轴
            chart->setAxisX(axisX,lineseries);
            chart->setAxisY(axisY,lineseries);
            chart->setTitle("正确率变化曲线");
            ui->graphicsView->setChart(chart);
            ui->graphicsView->setRenderHint(QPainter::Antialiasing);
            //ui->verticalLayout_10->addWidget(chartView);
        }
    }
    if(button == ui->dButton){
        if(ui->stackedWidget->currentIndex() == 5)
            return;
        else{
            ui->stackedWidget->setCurrentIndex(5);
            ui->comboBox_4->setCurrentIndex(Grade->Grade-1);
        }
    }
    if(button == ui->sButton){
        ui->stackedWidget->setCurrentIndex(1);
        User->set((ui->comboBox_2->currentIndex()+1)*10, ui->comboBox->currentIndex()+1);
        status = 1;
       }
    if(button == ui->pushButton_ret){
        ui->stackedWidget->setCurrentIndex(0);
        status = 0;
    }
    if(button == ui->pushButton_all)
        ui->stackedWidget->setCurrentIndex(1);
    if(button == ui->pushButton_one)
        ui->stackedWidget->setCurrentIndex(1);
    if(button == ui->subButton){
        ui->stackedWidget->setCurrentIndex(2);
        if(status == 1 || status == 3){
            User->checkans();
            User->save_error(status);
        }
        ui->label_rin->setText(QString::number(User->num-User->error_num-User->nfn));
        ui->label_rrn->setText(QString::number(User->rrn));
        ui->label_fan->setText(QString::number(User->error_num));
        ui->label_nfn->setText(QString::number(User->nfn));
        ui->label_time_2->setText(ui->label_time->text());
        status = 2;
    }
    if(button == ui->pushButton_0)
        ui->stackedWidget->setCurrentIndex(1);
    if(button == ui->pushButton_1)
        ui->stackedWidget->setCurrentIndex(1);
    if(button == ui->pushButton_2)
        ui->stackedWidget->setCurrentIndex(1);
    if(button == ui->pushButton_3)
        ui->stackedWidget->setCurrentIndex(1);
    if(button == ui->pushButton_4)
        ui->stackedWidget->setCurrentIndex(1);
    if(button == ui->pushButton_5)
        ui->stackedWidget->setCurrentIndex(1);
    if(button == ui->pushButton_6)
        ui->stackedWidget->setCurrentIndex(1);
    if(button == ui->pushButton_7)
        ui->stackedWidget->setCurrentIndex(1);
    if(button == ui->pushButton_8)
        ui->stackedWidget->setCurrentIndex(1);
    if(button == ui->pushButton_9)
        ui->stackedWidget->setCurrentIndex(1);
}

void MainWindow::flush(){
    QPushButton *button = qobject_cast<QPushButton*>(sender());//得到按下的按钮的指针
    if(button == ui->sButton){
        page = 1;
        page_all = ui->comboBox_2->currentIndex()+1;
        ui->lineEdit->clear();
        ui->lineEdit_1->clear();
        ui->lineEdit_2->clear();
        ui->lineEdit_3->clear();
        ui->lineEdit_4->clear();
        ui->lineEdit_5->clear();
        ui->lineEdit_6->clear();
        ui->lineEdit_7->clear();
        ui->lineEdit_8->clear();
        ui->lineEdit_9->clear();
    }
    if(button == ui->lButton){
        if(page == 1)
            return;
        page--;
        if(User->prob[(page-1)*10].stu_ans == -1) ui->lineEdit->clear();
        else ui->lineEdit->setText(QString::number(User->prob[(page-1)*10].stu_ans));
        if(User->prob[(page-1)*10+1].stu_ans == -1) ui->lineEdit_1->clear();
        else ui->lineEdit_1->setText(QString::number(User->prob[(page-1)*10+1].stu_ans));
        if(User->prob[(page-1)*10+2].stu_ans == -1) ui->lineEdit_2->clear();
        else ui->lineEdit_2->setText(QString::number(User->prob[(page-1)*10+2].stu_ans));
        if(User->prob[(page-1)*10+3].stu_ans == -1) ui->lineEdit_3->clear();
        else ui->lineEdit_3->setText(QString::number(User->prob[(page-1)*10+3].stu_ans));
        if(User->prob[(page-1)*10+4].stu_ans == -1) ui->lineEdit_4->clear();
        else ui->lineEdit_4->setText(QString::number(User->prob[(page-1)*10+4].stu_ans));
        if(User->prob[(page-1)*10+5].stu_ans == -1) ui->lineEdit_5->clear();
        else ui->lineEdit_5->setText(QString::number(User->prob[(page-1)*10+5].stu_ans));
        if(User->prob[(page-1)*10+6].stu_ans == -1) ui->lineEdit_6->clear();
        else ui->lineEdit_6->setText(QString::number(User->prob[(page-1)*10+6].stu_ans));
        if(User->prob[(page-1)*10+7].stu_ans == -1) ui->lineEdit_7->clear();
        else ui->lineEdit_7->setText(QString::number(User->prob[(page-1)*10+7].stu_ans));
        if(User->prob[(page-1)*10+8].stu_ans == -1) ui->lineEdit_8->clear();
        else ui->lineEdit_8->setText(QString::number(User->prob[(page-1)*10+8].stu_ans));
        if(User->prob[(page-1)*10+9].stu_ans == -1) ui->lineEdit_9->clear();
        else ui->lineEdit_9->setText(QString::number(User->prob[(page-1)*10+9].stu_ans));
    }
    if(button == ui->nButton){
        if(page == page_all)
            return;
        page++;
        if(User->prob[(page-1)*10].stu_ans == -1) ui->lineEdit->clear();
        else ui->lineEdit->setText(QString::number(User->prob[(page-1)*10].stu_ans));
        if(User->prob[(page-1)*10+1].stu_ans == -1) ui->lineEdit_1->clear();
        else ui->lineEdit_1->setText(QString::number(User->prob[(page-1)*10+1].stu_ans));
        if(User->prob[(page-1)*10+2].stu_ans == -1) ui->lineEdit_2->clear();
        else ui->lineEdit_2->setText(QString::number(User->prob[(page-1)*10+2].stu_ans));
        if(User->prob[(page-1)*10+3].stu_ans == -1) ui->lineEdit_3->clear();
        else ui->lineEdit_3->setText(QString::number(User->prob[(page-1)*10+3].stu_ans));
        if(User->prob[(page-1)*10+4].stu_ans == -1) ui->lineEdit_4->clear();
        else ui->lineEdit_4->setText(QString::number(User->prob[(page-1)*10+4].stu_ans));
        if(User->prob[(page-1)*10+5].stu_ans == -1) ui->lineEdit_5->clear();
        else ui->lineEdit_5->setText(QString::number(User->prob[(page-1)*10+5].stu_ans));
        if(User->prob[(page-1)*10+6].stu_ans == -1) ui->lineEdit_6->clear();
        else ui->lineEdit_6->setText(QString::number(User->prob[(page-1)*10+6].stu_ans));
        if(User->prob[(page-1)*10+7].stu_ans == -1) ui->lineEdit_7->clear();
        else ui->lineEdit_7->setText(QString::number(User->prob[(page-1)*10+7].stu_ans));
        if(User->prob[(page-1)*10+8].stu_ans == -1) ui->lineEdit_8->clear();
        else ui->lineEdit_8->setText(QString::number(User->prob[(page-1)*10+8].stu_ans));
        if(User->prob[(page-1)*10+9].stu_ans == -1) ui->lineEdit_9->clear();
        else ui->lineEdit_9->setText(QString::number(User->prob[(page-1)*10+9].stu_ans));
    }
    if(button == ui->pushButton_0){
        Errorlist->getprob(0,User);
        page = 1;
        page_all = User->num/10;
        status = 1;
        User->error_num = 0;
        User->nfn = 0;
        time = 0;
    }
    if(button == ui->pushButton_1){
        Errorlist->getprob(1,User);
        page = 1;
        page_all = (User->num-1)/10+1;
        status = 1;
        User->error_num = 0;
        User->nfn = 0;
        time = 0;
    }
    if(button == ui->pushButton_2){
        Errorlist->getprob(2,User);
        page = 1;
        page_all = (User->num-1)/10+1;
        status = 1;
        User->error_num = 0;
        User->nfn = 0;
        time = 0;
    }
    if(button == ui->pushButton_3){
        Errorlist->getprob(3,User);
        page = 1;
        status = 1;
        User->error_num = 0;
        User->nfn = 0;
        page_all = (User->num-1)/10+1;
        time = 0;
    }
    if(button == ui->pushButton_4){
        Errorlist->getprob(4,User);
        page = 1;
        page_all = (User->num-1)/10+1;
        status = 1;
        User->error_num = 0;
        User->nfn = 0;
        time = 0;
    }
    if(button == ui->pushButton_5){
        Errorlist->getprob(5,User);
        page = 1;
        page_all = (User->num-1)/10+1;
        status = 1;
        User->error_num = 0;
        User->nfn = 0;
        time = 0;
    }
    if(button == ui->pushButton_6){
        Errorlist->getprob(6,User);
        page = 1;
        page_all = (User->num-1)/10+1;
        status = 1;
        User->error_num = 0;
        User->nfn = 0;
        time = 0;
    }
    if(button == ui->pushButton_7){
        Errorlist->getprob(7,User);
        page = 1;
        page_all = (User->num-1)/10+1;
        status = 1;
        User->error_num = 0;
        User->nfn = 0;
        time = 0;
    }
    if(button == ui->pushButton_8){
        Errorlist->getprob(8,User);
        page = 1;
        page_all = (User->num-1)/10+1;
        status = 1;
        User->error_num = 0;
        User->nfn = 0;
        time = 0;
    }
    if(button == ui->pushButton_9){
        Errorlist->getprob(9,User);
        page = 1;
        page_all = (User->num-1)/10+1;
        status = 1;
        User->error_num = 0;
        User->nfn = 0;
        time = 0;
    }
    ui->label_page->setNum(page);
    ui->label_page->setAlignment(Qt::AlignCenter);
    ui->label_0->setText(QString::fromStdString(User->prob[(page-1)*10].prob));
    ui->label_0->setAlignment(Qt::AlignCenter);
    ui->label_1->setText(QString::fromStdString(User->prob[(page-1)*10+1].prob));
    ui->label_1->setAlignment(Qt::AlignCenter);
    ui->label_2->setText(QString::fromStdString(User->prob[(page-1)*10+2].prob));
    ui->label_2->setAlignment(Qt::AlignCenter);
    ui->label_3->setText(QString::fromStdString(User->prob[(page-1)*10+3].prob));
    ui->label_3->setAlignment(Qt::AlignCenter);
    ui->label_4->setText(QString::fromStdString(User->prob[(page-1)*10+4].prob));
    ui->label_4->setAlignment(Qt::AlignCenter);
    ui->label_5->setText(QString::fromStdString(User->prob[(page-1)*10+5].prob));
    ui->label_5->setAlignment(Qt::AlignCenter);
    ui->label_6->setText(QString::fromStdString(User->prob[(page-1)*10+6].prob));
    ui->label_6->setAlignment(Qt::AlignCenter);
    ui->label_7->setText(QString::fromStdString(User->prob[(page-1)*10+7].prob));
    ui->label_7->setAlignment(Qt::AlignCenter);
    ui->label_8->setText(QString::fromStdString(User->prob[(page-1)*10+8].prob));
    ui->label_8->setAlignment(Qt::AlignCenter);
    ui->label_9->setText(QString::fromStdString(User->prob[(page-1)*10+9].prob));
    ui->label_9->setAlignment(Qt::AlignCenter);
    if(User->prob[(page-1)*10].stu_ans == -1){
        ui->lineEdit->clear();
    }
    else{
        ui->lineEdit->setText(QString::number(User->prob[(page-1)*10].stu_ans));
    }
    if(User->prob[(page-1)*10+1].stu_ans == -1){
        ui->lineEdit->clear();
    }
    else{
        ui->lineEdit->setText(QString::number(User->prob[(page-1)*10+1].stu_ans));
    }
    if(User->prob[(page-1)*10+2].stu_ans == -1){
        ui->lineEdit->clear();
    }
    else{
        ui->lineEdit->setText(QString::number(User->prob[(page-1)*10+2].stu_ans));
    }
    if(User->prob[(page-1)*10+3].stu_ans == -1){
        ui->lineEdit->clear();
    }
    else{
        ui->lineEdit->setText(QString::number(User->prob[(page-1)*10+3].stu_ans));
    }
    if(User->prob[(page-1)*10+4].stu_ans == -1){
        ui->lineEdit->clear();
    }
    else{
        ui->lineEdit->setText(QString::number(User->prob[(page-1)*10+4].stu_ans));
    }
    if(User->prob[(page-1)*10+5].stu_ans == -1){
        ui->lineEdit->clear();
    }
    else{
        ui->lineEdit->setText(QString::number(User->prob[(page-1)*10+5].stu_ans));
    }
    if(User->prob[(page-1)*10+6].stu_ans == -1){
        ui->lineEdit->clear();
    }
    else{
        ui->lineEdit->setText(QString::number(User->prob[(page-1)*10+6].stu_ans));
    }
    if(User->prob[(page-1)*10+7].stu_ans == -1){
        ui->lineEdit->clear();
    }
    else{
        ui->lineEdit->setText(QString::number(User->prob[(page-1)*10+7].stu_ans));
    }
    if(User->prob[(page-1)*10+8].stu_ans == -1){
        ui->lineEdit->clear();
    }
    else{
        ui->lineEdit->setText(QString::number(User->prob[(page-1)*10+8].stu_ans));
    }
    if(User->prob[(page-1)*10+9].stu_ans == -1){
        ui->lineEdit->clear();
    }
    else{
        ui->lineEdit->setText(QString::number(User->prob[(page-1)*10+9].stu_ans));
    }
}

void MainWindow::trans(){
    QLineEdit *line = qobject_cast<QLineEdit*>(sender());
    if(line == ui->lineEdit && ui->lineEdit->text()!=""){
        User->prob[(page-1)*10].stu_ans = ui->lineEdit->text().toInt();
    }
    if(line == ui->lineEdit_1&& ui->lineEdit_1->text()!=""){
        User->prob[(page-1)*10+1].stu_ans = ui->lineEdit_1->text().toInt();
    }
    if(line == ui->lineEdit_2&& ui->lineEdit_2->text()!=""){
        User->prob[(page-1)*10+2].stu_ans = ui->lineEdit_2->text().toInt();
    }
    if(line == ui->lineEdit_3&& ui->lineEdit_3->text()!=""){
        User->prob[(page-1)*10+3].stu_ans = ui->lineEdit_3->text().toInt();
    }
    if(line == ui->lineEdit_4&& ui->lineEdit_4->text()!=""){
        User->prob[(page-1)*10+4].stu_ans = ui->lineEdit_4->text().toInt();
    }
    if(line == ui->lineEdit_5&& ui->lineEdit_5->text()!=""){
        User->prob[(page-1)*10+5].stu_ans = ui->lineEdit_5->text().toInt();
    }
    if(line == ui->lineEdit_6&& ui->lineEdit_6->text()!=""){
        User->prob[(page-1)*10+6].stu_ans = ui->lineEdit_6->text().toInt();
    }
    if(line == ui->lineEdit_7&& ui->lineEdit_7->text()!=""){
        User->prob[(page-1)*10+7].stu_ans = ui->lineEdit_7->text().toInt();
    }
    if(line == ui->lineEdit_8&& ui->lineEdit_8->text()!=""){
        User->prob[(page-1)*10+8].stu_ans = ui->lineEdit_8->text().toInt();
    }
    if(line == ui->lineEdit_9&& ui->lineEdit_9->text()!=""){
        User->prob[(page-1)*10+9].stu_ans = ui->lineEdit_9->text().toInt();
    }
}
void MainWindow::getrrn(){
    fstream file;
    int i;
    file.open("RRN.txt", ios_base::in);
    for(i = 0; i < 10; i++){
        if(!(file >> RRN[i])) break;
    }
    while(i!=10){
        RRN[i] = 0;
    }
}

void MainWindow::settings(){
    Grade->change(ui->comboBox_4->currentIndex()+1);
    disable_item();
}

void MainWindow::disable_item(){
    if(Grade->Grade == 1){
        QModelIndex index = ui->comboBox->model()->index(3, 0);
        QVariant v(0);
        ui->comboBox->model()->setData(index, v, Qt::UserRole - 1);
        index = ui->comboBox->model()->index(4, 0);
        ui->comboBox->model()->setData(index, v, Qt::UserRole - 1);
        index = ui->comboBox->model()->index(5, 0);
        ui->comboBox->model()->setData(index, v, Qt::UserRole - 1);
    }
    else{
        QModelIndex index = ui->comboBox->model()->index(3, 0);
        QVariant v(-1);
        ui->comboBox->model()->setData(index, v, Qt::UserRole - 1);
        index = ui->comboBox->model()->index(4, 0);
        ui->comboBox->model()->setData(index, v, Qt::UserRole - 1);
        index = ui->comboBox->model()->index(5, 0);
        ui->comboBox->model()->setData(index, v, Qt::UserRole - 1);
    }
}
void MainWindow::timerUpDate(){
    time ++;
    int min = time / 60;
    int sec = time % 60;
    string t = to_string(min) + ":" + to_string(sec);
    ui->label_time->setText(QString::fromStdString(t));
    ui->label_time->setAlignment(Qt::AlignCenter);
}
void MainWindow::settime(){
    time = 0;
}
